﻿namespace snake
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const int maxLengteSlang = 20; // maximale lengte van de slang

            int lengteSlang = 1; // huidige lengte van de slang

            int[] xPositiesSlang = new int[maxLengteSlang]; // kop van de slang staat op indexpositie 0
            int[] yPositiesSlang = new int[maxLengteSlang]; // staart van de slang staat op indexpositie lengteSlang-1

            // verplaats kop van de slang naar midden van scherm
            xPositiesSlang[0] = Console.WindowWidth / 2;
            yPositiesSlang[0] = Console.WindowHeight / 2;

            // teken slang eerste keer (loop voor het geval we eens willen starten met een langere slang)
            for (int i = 0; i < lengteSlang; i++)
            {
                Console.SetCursorPosition(xPositiesSlang[i], yPositiesSlang[i]);
                Console.Write("☺");
            }

            int xPositieAppel = 10;
            int yPositieAppel = 10;

            Random rnd = new Random();
            Console.CursorVisible = false;

            // teken appel eerste keer
            // (eigenlijk zouden we hier moeten checken dat we de appel niet op de slang plaatsen)
            Console.SetCursorPosition(xPositieAppel, yPositieAppel);
            Console.Write("A");

            while (true)
            {
                // verplaats slang indien de gebruiker op een pijltjestoets toets drukt
                if (Console.KeyAvailable)
                {
                    // bepaal wat de nieuwe positie van de kop zou zijn als de slang zich zou verplaatsen
                    bool isVerplaatst = false;
                    int nieuweXPositieKop = xPositiesSlang[0];
                    int nieuweYPositieKop = yPositiesSlang[0];

                    ConsoleKeyInfo cki = Console.ReadKey(true); // true parameter betekent dat key niet zal getoond worden
                    if (cki.Key == ConsoleKey.LeftArrow)
                    {
                        nieuweXPositieKop--;
                        // enkel verplaatsen indien nieuwe positie binnen speelveld ligt
                        if (nieuweXPositieKop >= 0)
                        {
                            isVerplaatst = true;
                        }
                    }
                    else if (cki.Key == ConsoleKey.RightArrow)
                    {
                        nieuweXPositieKop++;
                        // enkel verplaatsen indien nieuwe positie binnen speelveld ligt
                        if (nieuweXPositieKop <= Console.WindowWidth - 1)
                        {
                            isVerplaatst = true;
                        }
                    }
                    else if (cki.Key == ConsoleKey.UpArrow)
                    {
                        nieuweYPositieKop--;
                        // enkel verplaatsen indien nieuwe positie binnen speelveld ligt
                        if (nieuweYPositieKop >= 0)
                        {
                            isVerplaatst = true;
                        }
                    }
                    else if (cki.Key == ConsoleKey.DownArrow)
                    {
                        nieuweYPositieKop++;
                        // enkel verplaatsen indien nieuwe positie binnen speelveld ligt
                        if (nieuweYPositieKop <= Console.WindowHeight - 1)
                        {
                            isVerplaatst = true;
                        }
                    }

                    if (isVerplaatst)
                    {
                        // kan de slang bewegen zonder zichzelf te bijten?
                        bool zouZichzelfBijten = false;
                        for (int i = 0; i < lengteSlang-1; i++) // -1 omdat laatste uiteinde staart bijten eigenlijk niet kan
                        {
                            if (nieuweXPositieKop == xPositiesSlang[i] && nieuweYPositieKop == yPositiesSlang[i])
                            {
                                zouZichzelfBijten = true;
                                break;
                            }
                        }

                        if (!zouZichzelfBijten)
                        {
                            bool isAppelOpgegeten = (nieuweXPositieKop == xPositieAppel && nieuweYPositieKop == yPositieAppel);
                            if (isAppelOpgegeten)
                            {
                                // kan de slang nog groeien?
                                if (lengteSlang < maxLengteSlang)
                                {
                                    // slang kan groeien bovenop de verplaatsing
                                    Array.Copy(xPositiesSlang, 0, xPositiesSlang, 1, lengteSlang);
                                    Array.Copy(yPositiesSlang, 0, yPositiesSlang, 1, lengteSlang);
                                    lengteSlang++;

                                    xPositiesSlang[0] = nieuweXPositieKop;
                                    yPositiesSlang[0] = nieuweYPositieKop;
                                }
                                else
                                {
                                    // slang kan niet groeien, dus gewoon verplaatsen
                                    // (is identieke code als gewoon verplaatsen zonder appel te eten)

                                    // wis uiteinde staart
                                    Console.SetCursorPosition(xPositiesSlang[lengteSlang - 1], yPositiesSlang[lengteSlang - 1]);
                                    Console.Write(" ");

                                    // schuif waarden in de arrays op, 1 positie meer naar het einde toe
                                    Array.Copy(xPositiesSlang, 0, xPositiesSlang, 1, lengteSlang - 1);
                                    Array.Copy(yPositiesSlang, 0, yPositiesSlang, 1, lengteSlang - 1);

                                    // stop de nieuwe positie van de kop in de arrays
                                    xPositiesSlang[0] = nieuweXPositieKop;
                                    yPositiesSlang[0] = nieuweYPositieKop;
                                }

                                // bepaal nieuwe positie appel
                                // (eigenlijk zouden we hier moeten checken dat we de appel niet op de slang plaatsen)
                                xPositieAppel = rnd.Next(0, Console.WindowWidth);
                                yPositieAppel = rnd.Next(0, Console.WindowHeight);

                                // teken appel op nieuwe positie
                                Console.SetCursorPosition(xPositieAppel, yPositieAppel);
                                Console.Write("A");
                            }
                            else
                            {
                                // geen appel gegeten, dus de slang verplaatst zich gewoon

                                // wis uiteinde staart
                                Console.SetCursorPosition(xPositiesSlang[lengteSlang - 1], yPositiesSlang[lengteSlang - 1]);
                                Console.Write(" ");

                                // schuif waarden in de arrays op, 1 positie meer naar het einde toe
                                Array.Copy(xPositiesSlang, 0, xPositiesSlang, 1, lengteSlang - 1);
                                Array.Copy(yPositiesSlang, 0, yPositiesSlang, 1, lengteSlang - 1);

                                // stop de nieuwe positie van de kop in de arrays
                                xPositiesSlang[0] = nieuweXPositieKop;
                                yPositiesSlang[0] = nieuweYPositieKop;
                            }

                            // teken kop op nieuwe positie
                            // we doen dit NA het wissen van het uiteinde vd staart, anders zouden we de kop
                            // wissen indien nieuwe positie kop == vorige positie uiteinde staart (i.e. als de slang
                            // net niet in zijn eigen staart bijt
                            Console.SetCursorPosition(nieuweXPositieKop, nieuweYPositieKop);
                            Console.Write("☺");
                        }
                    }

                    // haal alle overige toetsdrukken uit de keyboard buffer
                    // als de gebruiker lange tijd bv. op linker pijltje drukt, dan vult de keyboard buffer
                    // zich daarmee waardoor de slang steeds nog een tijdje door blijft gaan als je de toets loslaat
                    // (als dit niet duidelijk is : zet onderstaande loop in commentaar en probeer het eens uit)
                    while (Console.KeyAvailable)
                    {
                        Console.ReadKey(true);
                    }
                }
                // kleine vertraging zodat het bij iedereen +- even snel loopt en niet afhankelijk
                // is van de keyboard repeat rate, d.i. een instelling van het operating systeem (windows, linux, osx, ..)
                Thread.Sleep(50);

            }


        }
    }
}