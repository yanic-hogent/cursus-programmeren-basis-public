﻿using System;

namespace TestJezelf.Gemeenteraad {
    class Program {
        static void Main() {
            Console.WriteLine("De uitvoer van oefening Gemeenteraad...");
        }
    }
}