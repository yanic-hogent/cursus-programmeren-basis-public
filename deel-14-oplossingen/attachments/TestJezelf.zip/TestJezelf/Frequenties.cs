﻿using System;

namespace TestJezelf.Frequenties {
    class Program {
        static void Main() {
            Console.WriteLine("De uitvoer van oefening Frequenties...");
        }
    }
}