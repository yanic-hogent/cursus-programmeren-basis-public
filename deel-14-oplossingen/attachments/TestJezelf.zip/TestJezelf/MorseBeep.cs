﻿using System;

namespace TestJezelf.MorseBeep {
    class Program {
        static void Main() {
            Console.WriteLine("De uitvoer van oefening MorseBeep...");
        }
    }
}