﻿using System.Collections.Generic;
using System.Drawing;

namespace Domain {
    public class Diagram {

        private List<Figure> Figures { get; set; }

        public Diagram() {
            this.Figures = new List<Figure>();
        }

        public void Add(Figure f) {
            // Figuur toevoegen aan de lijst
            this.Figures.Add(f);
        }

        public void DrawAll(Graphics gfx) {
            // Alle figuren overlopen en van elke figuur de Draw method oproepen
            foreach (Figure f in Figures) {
                f.Draw(gfx);
            }
        }
    }
}
