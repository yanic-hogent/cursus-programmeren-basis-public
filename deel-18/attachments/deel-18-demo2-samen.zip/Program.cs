using System;
using System.Windows.Forms;
using Domain;
using UI;

static class Program {
    /// <summary>
    ///  The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main() {
        Application.SetHighDpiMode(HighDpiMode.SystemAware);
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);

        // maak een venster aan
        Form form = new Form();

        // stel de initiele grootte van dit venster in
        form.ClientSize = new System.Drawing.Size(400, 500);

        // stel de titel van het venster in
        form.Text = "Diagram";

        // maak een diagram en voeg rechthoeken en cirkels toe
        Diagram diagram = new Diagram();
        Figure r1 = new Figure(100, 100, 100, 200, System.Drawing.Color.Red, true);
        diagram.Add(r1);
        Figure c1 = new Figure(150, 150, 60, System.Drawing.Color.Green, true);
        diagram.Add(c1);
        Figure c2 = new Figure(325, 285, 30, System.Drawing.Color.Yellow, true);
        diagram.Add(c2);
        Figure r2 = new Figure(300, 300, 50, 50, System.Drawing.Color.Blue, true);
        diagram.Add(r2);

        // maak een control (= ui onderdeel) en voeg toe aan dit venster
        Control control = new DiagramControl(diagram);
        form.Controls.Add(control);

        // zorg ervoor dat drawing control ganse venster inneemt
        control.Dock = DockStyle.Fill;

        // Start de grafische user interface en toon de form
        Application.Run(form);
    }
}