﻿using System.Drawing;

namespace Domain {

    public class Figure {
        private enum FigureKind { Circle, Rectangle }

        // Property die vastlegt of het Figure object
        // een cirkel dan wel een rechthoek voorstelt
        private FigureKind Kind { get; set; }

        // Rechthoek-specifieke properties 
        public int RectangleTop { get; set; }
        public int RectangleLeft { get; set; }
        public int RectangleWidth { get; set; }
        public int RectangleHeight { get; set; }
        public Color RectangleColor { get; set; }
        public bool RectangleIsFilled { get; set; }

        // Constructor om een Figure object te maken dat
        // een rechthoek voorstelt
        public Figure(int left, int top, int width, int height, Color color, bool isFilled) {
            this.Kind = FigureKind.Rectangle;
            this.RectangleTop = top;
            this.RectangleLeft = left;
            this.RectangleWidth = width;
            this.RectangleHeight = height;
            this.RectangleColor = color;
            this.RectangleIsFilled = isFilled;
        }

        // Cirkel-specifieke properties
        public int CircleCenterX { get; set; }
        public int CircleCenterY { get; set; }
        public int CircleRadius { get; set; }
        public Color CircleColor { get; set; }
        public bool CircleIsFilled { get; set; }

        // Constructor om een Figure object te maken dat
        // een cirkel voorstelt
        public Figure(int centerX, int centerY, int radius, Color color, bool isFilled) {
            this.Kind = FigureKind.Circle;
            this.CircleCenterX = centerX;
            this.CircleCenterY = centerY;
            this.CircleRadius = radius;
            this.CircleColor = color;
            this.CircleIsFilled = isFilled;
        }

        // Teken deze Figure
        // (naargelang de waarde van property 'this.Kind'
        // wordt een rechthoek of een cirkel getekend)
        public void Draw(Graphics gfx) {
            if (this.Kind == FigureKind.Rectangle) {
                // Teken een rechthoek
                if (this.RectangleIsFilled) {
                    Brush brush = new SolidBrush(this.RectangleColor);
                    gfx.FillRectangle(brush, this.RectangleLeft, this.RectangleTop, this.RectangleWidth, this.RectangleHeight);
                } else {
                    Pen pen = new Pen(this.RectangleColor);
                    gfx.DrawRectangle(pen, this.RectangleLeft, this.RectangleTop, this.RectangleWidth, this.RectangleHeight);
                }
            } else if (this.Kind == FigureKind.Circle) {
                // Teken een cirkel
                int topLeftX = this.CircleCenterX - this.CircleRadius;
                int topLeftY = this.CircleCenterY - this.CircleRadius;
                int diameter = 2 * this.CircleRadius;
                if (this.CircleIsFilled) {
                    Brush brush = new SolidBrush(this.CircleColor);
                    gfx.FillEllipse(brush, topLeftX, topLeftY, diameter, diameter);
                } else {
                    Pen pen = new Pen(this.CircleColor);
                    gfx.DrawEllipse(pen, topLeftX, topLeftY, diameter, diameter);
                }

            }
        }
    }
}
